$(document).ready(function(){
    $(window).scroll(function(){
		var windowWidth = $(window).width();
		if (windowWidth > 900){
			var scroll = $(window).scrollTop();

			
			$('.acerca-de article').css({
				'transform': 'translate(0px, -' + scroll / 8 + '%)'
			});
		}
    });
    var acercaDe = $('#acerca-de').offset().top;
    $('#acerca, #flecha').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: acercaDe -60
        }, 900);
    });
    var window2 = $(window).width();
    if (window2 < 900){
        $('#acerca, #flecha').on('click', function(e){
            e.preventDefault();
            $('html, body').animate({
                scrollTop: acercaDe 
            }, 800);
        });
    }
   
    var ubicacion = $('#ubi').offset().top;
    $('#ubicacion').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: ubicacion -40
        },1200);
    });
    var contacto = $('#contacto1').offset().top;
    $('#contacto').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: contacto -40
        },1500);
    });
});