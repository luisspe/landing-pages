$(document).ready(function(){
    $('#flecha').css({
        opacity:0
    });
    $('#ocultados').css({
        opacity:0
    })
    $('#puntos').on('click', function(){
        $('#contenedor').animate({
            opacity:0
        },500);

        $('#ocultados').css({
            opacity:1,
            pointerEvents:'all'
        });
        $('#puntos').css({
            opacity:0,
            pointerEvents:'none'
        });
        $('#flecha').animate({
            opacity:1,
        },500);
        $('#flecha').css({
            pointerEvents:'all'
        });
        $('#1').css({
            opacity: 0,
            marginLeft: '-40px'
        });
        $('#1').animate({
            opacity: 1,
            marginLeft: '20px'
        },800);
        $('#2').css({
            opacity: 0,
            marginRight: '-40px'
        });
        $('#2').animate({
            opacity: 1,
            marginRight: '20px'
        },800);
        $('#3').css({
            opacity: 0,
            marginLeft: '-40px'
        });
        $('#3').animate({
            opacity: 1,
            marginLeft: '20px'
        },800);
        $('#4').css({
            opacity: 0,
            marginRight: '-40px'
        });
        $('#4').animate({
            opacity: 1,
            marginRight: '20px'
        },800);
    });
    $('#flecha').on('click', function(){
        $('#contenedor').animate({
            opacity:.85
        },500);
        $('#flecha').animate({
            opacity:0
        });
        $('#flecha').css({
            pointerEvents:'none'
        });
        $('#ocultados').css({
            opacity:0,
            pointerEvents:'none'
        });
        $('#puntos').css({
            opacity:1,
            pointerEvents:'all'
        });
        
   
    });
    
});